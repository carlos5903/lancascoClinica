<!doctype html>
<html>
    <head>
    <link rel="shortcut icon" href="#" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css'>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css'>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/css/mdb.min.css'><link rel="stylesheet" href="./style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



        <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- FontAwesom CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">        
    <!--Sweet Alert 2 -->
    <link rel="stylesheet" href="plugins/sweetalert2/sweetalert2.min.css">        
    <!--CSS custom -->  
    <link rel="stylesheet" href="main.css">
        <style>
            body  {
                background-image: url("images/38-texturas-gratuitas-tb-800x0.png");
                background-repeat: no-repeat;
                background-repeat: repeat;
                background-color: #cccccc;
            }

            img {
                border-radius: 50%;
            }
        </style>
    </head>
    <body>
    <header>
    </header>

    <section class="principal">


        <div class="container mt-4">

            <div class="card mb-4">
                <div class="card-body">
                    <!-- Grid row -->
                    <div class="row">
                        <!-- Grid column -->
                        <div class="col-md-12">

                            <h2 class="text-center text-dark"><img src="images/icons8-services.png" alt="Paris" width="50" height="50"><span class="badge badge-success">Mantenimiento de Extensiones</span><img src="images/icons8-maintenance.png" alt="Paris" width="50" height="50"></h2>

                        </div>
                        <!-- Grid column -->

                    </div>
                    <!-- Grid row -->
                </div>
            </div>
            <div class="card mb-4 ">

                <!-- Grid row -->
                <div id="appMoviles">
                    <div class="container">
                        <div class="row">

                            <div class="col">

                                <button @click="btnAlta" class="btn btn-success" title="Nuevo"><i class="fas fa-plus-circle fa-2x"></i></button>
                                <div class="input-group md-form form-sm form-2 pl-0">
                                    <input type="text" name="caja_busqueda" id="caja_busqueda" onkeyup="myFunction()" class="form-control my-0 py-1 pl-3 purple-border" type="text" placeholder="Buscar por nombre" aria-label="Search">
                                    <span class="input-group-addon waves-effect purple lighten-2" id="basic-addon1"><a><i class="fa fa-search white-text" aria-hidden="true"></i></a></span>
                                </div>
                            </div>
                            <script>
                                function myFunction() {
                                    var input, filter, table, tr, td, i, txtValue;
                                    input = document.getElementById("caja_busqueda");
                                    filter = input.value.toUpperCase();
                                    table = document.getElementById("extensionestabla");
                                    tr = table.getElementsByTagName("tr");
                                    for (i = 0; i < tr.length; i++) {
                                        td = tr[i].getElementsByTagName("td")[2];
                                        if (td) {
                                            txtValue = td.textContent || td.innerText;
                                            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                                tr[i].style.display = "";
                                            } else {
                                                tr[i].style.display = "none";
                                            }
                                        }
                                    }
                                }
                            </script>
                        </div>

                        <div  class=" row d-flex justify-content-center" id="datos"></div>
                        <div class="row mt-5">
                            <div class="col-lg-12">

                                <table  id="extensionestabla" class="table table-dark">

                                    <thead class='table-dark'>

                                    <tr id='titulo'>
                                        <td>ID</td>
                                        <td>Extension</td>
                                        <td class='bg-dark'>Nombre</td>
                                        <td>Puesto</td>
                                        <td class='bg-dark'>Departamento</td>
                                        <td>Empresa</td>
                                    </tr>

                                    </thead>
                                    <tbody>
                                    <tr v-for="(movil,indice) of moviles">
                                        <td>{{movil.id}}</td>
                                        <td class='bg-dark' >{{movil.extension}}</td>
                                        <td>{{movil.nombre}}</td>
                                        <td class='bg-dark'>{{movil.puesto}}</td>
                                        <td>{{movil.departamento}}</td>

                                        <td class='bg-dark'>{{movil.empresa}}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-secondary" title="Editar" @click="btnEditar(movil.id,movil.extension, movil.nombre, movil.puesto, movil.departamento, movil.empresa)"><i class="fas fa-pencil-alt"></i></button>
                                                <button class="btn btn-danger" title="Eliminar" @click="btnBorrar(movil.id)"><i class="fas fa-trash-alt"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                    <div  class=" row d-flex justify-content-center" id="datos"></div>

                </div>
                    </div>
                </div>

            </div>


    </section>

    <script type="text/javascript" src="js/main.js"></script>
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>         
    <!--Vue.JS -->    
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>              
    <!--Axios -->      
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.15.2/axios.js"></script>    
    <!--Sweet Alert 2 -->        
    <script src="plugins/sweetalert2/sweetalert2.all.min.js"></script>      
    <!--Código custom -->          
    <script src="main.js"></script>         
    </body>
</html>