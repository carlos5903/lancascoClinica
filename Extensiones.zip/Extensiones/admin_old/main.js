var url = "bd/crud.php";

var appMoviles = new Vue({    
el: "#appMoviles",   
data:{     
     moviles:[],          
     departamento:"",
     nombre:"",
     puesto:"",
     EXT:"",
     empresa:"",

 },    
methods:{  
    //BOTONES        
    btnAlta:async function(){                    
        const {value: formValues} = await Swal.fire({
        title: 'NUEVO',
        html:
        '<div class="row"><label class="col-sm-4 col-form-label">Departamento</label><div class="col-sm-7"><input id="departamento" type="text" class="form-control"></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Nombre</label><div class="col-sm-7"><input id="nombre" type="text" class="form-control"></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Puesto</label><div class="col-sm-7"><input id="puesto" type="text" class="form-control"></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Extension</label><div class="col-sm-7"><input id="EXT" type="text" class="form-control"></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Empresa</label><select class="custom-select col-sm-7" id="empresa" required>\n' +
        '<option value="">Elija una empresa</option>\n' +
        '<option value="1">Scentia</option>\n' +
        '<option value="2">Lancasco</option>\n'+
        '</select>',
        focusConfirm: false,
        showCancelButton: true,
        confirmButtonText: 'Guardar',          
        confirmButtonColor:'#1cc88a',          
        cancelButtonColor:'#3085d6',  
        preConfirm: () => {            
            return [
             this.departamento = document.getElementById('departamento').value,
             this.nombre = document.getElementById('nombre').value,
             this.puesto = document.getElementById('puesto').value,
             this.EXT = document.getElementById('EXT').value,
             this.empresa = document.getElementById('empresa').value
            ]
          }
        })        
        if(this.departamento == "" || this.nombre == "" || this.puesto == "" || this.EXT == "" || this.empresa == ""){
                Swal.fire({
                  type: 'info',
                  title: 'Datos incompletos ',
                }) 
        }       
        else{          
          this.altaMovil();          
          const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 3000
            });
            Toast.fire({
              type: 'success',
              title: '¡Extension Agregada!'
            })                
        }
    },           
    btnEditar:async function(id, EXT, nombre, departamento, puesto, empresa){
        await Swal.fire({
        title: 'EDITAR',
        html:
        '<div class="form-group"><div class="row"><label class="col-sm-4 col-form-label">Extension</label><div class="col-sm-7"><input id="EXT" value="'+EXT+'" type="text" class="form-control"></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Nombre</label><div class="col-sm-7"><input id="nombre" value="'+nombre+'" type="text" class="form-control"></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Departamento</label><div class="col-sm-7"><input id="departamento" value="'+departamento+'" type="text" class="form-control"></div></div></div>'+
        '<div class="row"><label class="col-sm-4 col-form-label">Puesto</label><div class="col-sm-7"><input id="puesto" value="'+puesto+'" type="text"  class="form-control"></div></div></div>' +
        '<div class="row"><label class="col-sm-4 col-form-label">Empresa</label><select class="custom-select col-sm-7" id="empresa">\n' +
        '<option value="">Elija una empresa</option>\n' +
        '<option value="1">Scentia</option>\n' +
        '<option value="2">Lancasco</option>\n'+
        '</select>',
        focusConfirm: false,
        showCancelButton: true,                         
        }).then((result) => {
          if (result.value) {

              this.EXT = document.getElementById('EXT').value,
                  this.nombre = document.getElementById('nombre').value,

                  this.departamento = document.getElementById('departamento').value,

                  this.puesto = document.getElementById('puesto').value,

                  this.empresa = document.getElementById('empresa').value

              this.editarMovil(id, EXT, nombre, departamento, puesto, empresa);

                  Swal.fire(
                      '¡Actualizado!',
                      'El registro ha sido actualizado.',
                      'success'
                  )
              }

        });
        
    },        
    btnBorrar:function(id){
        Swal.fire({
          title: '¿Está seguro de borrar el registro: '+id+" ?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor:'#d33',
          cancelButtonColor:'#3085d6',
          confirmButtonText: 'Borrar'
        }).then((result) => {
          if (result.value) {            
            this.borrarMovil(id);
            //y mostramos un msj sobre la eliminación  
            Swal.fire(
              '¡Eliminado!',
              'El registro ha sido borrado.',
              'success'
            )
          }
        })                
    },       
    
    //PROCEDIMIENTOS para el CRUD     
    listarMoviles:function(){
        axios.post(url, {opcion:4}).then(response =>{
           this.moviles = response.data;       
        });
    },    
    //Procedimiento CREAR.
    altaMovil:function(){
        //departamento, nombre, puesto, EXT, empresa
        axios.post(url, {opcion:1, departamento:this.departamento, nombre:this.nombre, puesto:this.puesto, EXT:this.EXT, empresa:this.empresa }).then(response =>{
            this.listarMoviles();
        });
        this.departamento = "",
        this.nombre = "",
        this.puesto = "",
        this.EXT = "",
        this.empresa = ""
    },               
    //Procedimiento EDITAR.
    editarMovil:function(id,EXT, nombre, departamento, puesto, empresa){
       axios.post(url, {opcion:2, id:id, departamento:this.departamento, nombre:this.nombre, puesto:this.puesto, EXT:this.EXT, empresa:this.empresa }).then(response =>{
           this.listarMoviles();           
        });                              
    },
    //Procedimiento BORRAR.
    borrarMovil:function(id){
        axios.post(url, {opcion:3, id:id}).then(response =>{
            this.listarMoviles();
        });
    }
},      
created: function(){            
   this.listarMoviles();            
},
    computed:{
        totalStock(){
            this.total = 0;
            for(movil of this.moviles){
                this.total = this.total + parseInt(movil.stock);
            }
            return this.total;
        }
    }
});