<?php
	$servername = "localhost";
    $username = "testuser";
  	$password = "test";
  	$dbname = "extensiones";

	$conn = new mysqli($servername, $username, $password, $dbname);
      if($conn->connect_error){
        die("Conexión fallida: ".$conn->connect_error);
      }



    $query = "SELECT * FROM extensiones  ORDER BY id ASC ";




    if (isset($_POST['consulta'])) {
    	$q = $conn->real_escape_string($_POST['consulta']);
    	$query = "SELECT * FROM extensiones WHERE extension LIKE '%$q%' OR Nombre LIKE '%$q%' OR Puesto LIKE '%$q%' OR Departamento LIKE '%$q%' OR Empresa LIKE '$q' ";
    }

    $resultado = $conn->query($query);

    if ($resultado->num_rows>0) {
    	$salida.="<table class=\"table table-dark\">
    			<thead class='table-dark'>
    				<tr id='titulo'>
    				    
    					<td>Extension</td>
    					<td class='bg-dark'>Nombre</td>
    					<td>Puesto</td>
    					<td class='bg-dark'>Departamento</td>
    					<td>Empresa</td>
    					<td class='bg-dark' >País</td>
    				</tr>

    			</thead>
    			

    	<tbody>";


    	while ($fila = $resultado->fetch_assoc()) {
            if ($fila["empresa"] == 1){
                $status ="<span class=\"role member\">Scentia</span>";
                if ($fila["pais"] == 1){
                    $pais ="<span class=\"role member\"> Guatemala </span>";

                }elseif ($fila["pais"] == 2){
                    $pais ="<span class=\"role au-btn--blue\"> Honduras </span>";
                }elseif ($fila["pais"] == 3){
                $pais ="<span class=\"role au-btn--blue2\">Salvador </span>";

            }elseif ($fila["pais"] == 7 ){
                $pais ="<span class=\"role au-btn--blue\"> Nicaragua </span>";

            }


                $salida.="<tr>
                           
    					<td  class=\"bg-success\" >".$fila['extension']."</td>
    					<td class='bg-dark'>".$fila['Nombre']."</td>
    					<td class=\"bg-secondary\">".$fila['Puesto']."</td>
    					<td class='bg-info'>".$fila['Departamento']."</td>
    					<td class=\"bg-white\">".$status."</td>
    					<td class=\"bg-dark\">".$pais."</td>
    					
    				</tr>";

            }else{
                $status2 ="<span class=\"role admin\">Lancasco</span>";

                if ($fila["pais"] == 1){
                    $pais ="<span class=\"role member\"> Guatemala </span>";

                }elseif ($fila["pais"] == 2){
                    $pais ="<span class=\"role au-btn--blue\"> Honduras </span>";
                }elseif ($fila["pais"] == 3){
                    $pais ="<span class=\"role au-btn--blue2\">Salvador </span>";

                }elseif ($fila["pais"] == 7 ){
                    $pais ="<span class=\"role au-btn--blue\"> Nicaragua </span>";

                }
                $salida.="<tr>
                       
    					<td class=\"bg-danger\">".$fila['extension']."</td>
    					<td >".$fila['Nombre']."</td>
    					<td class=\"bg-secondary\">".$fila['Puesto']."</td>       
    					<td class='bg-info'>".$fila['Departamento']."</td>
    					<td class=\"bg-white\">".$status2."</td>
    					<td class=\"bg-dark\">".$pais."</td>
    				</tr>";
            }


    	}
    	$salida.="</tbody></table>";
    }else{
    	$salida.="NO HAY DATOS :(";
    }


    echo $salida;

    $conn->close();



?>