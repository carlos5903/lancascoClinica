<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/css/mdb.min.css'><link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="css/theme.css" rel="stylesheet" media="all">
    <link rel="shortcut icon" type="image/x-icon" href="./images/Corporacion%20Lancasco.ico">
    <title>Extensiones Scentia / Lancasco</title>
    <style>
    body  {
    background-image: url("images/38-texturas-gratuitas-tb-800x0.png");
        background-repeat: no-repeat;
        background-repeat: repeat;
        background-color: #cccccc;
    }

    img {
        border-radius: 50%;
    }

    table td {
        font-size: 26px;
        font-weight: 300;
        text-align:center;

    }
    #caja_busqueda {
        font-size: 26px;
        text-align:center;
    }


    input[type='text'] { font-size: 24px; font-family: monospace; }
    </style>
</head>
<body >

<section class="principal">


    <div class="container mt-4">

        <div class="card mb-4">
            <div class="card-body">
                <!-- Grid row -->
                <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-12">


                        <h2 class="py-3 text-center font-bold font-up success-text"> <img src="images/scentia.png" alt="Paris" width="150" height="100">  Directorio de Extensiones <img src="images/logo1.ico" alt="Paris" width="80" height="100"></h2>
                    </div>


                    <!-- Grid column -->
                    <div class="input-group md-form form-sm form-2 pl-0">
                        <input type="text" name="caja_busqueda" id="caja_busqueda" class="form-control my-0 py-1 pl-3 purple-border" placeholder="Buscar por nombre, puesto, ext, departamento" aria-label="Search">
                        <span class="input-group-addon waves-effect purple lighten-2" id="basic-addon1"><a><i class="fa fa-search white-text" aria-hidden="true"></i></a></span>
                    </div>
                </div>
                <!-- Grid row -->

            </div>
        </div>
        <div class="card mb-4 ">

                <!-- Grid row -->
            <div  class=" row d-flex justify-content-center" id="datos"></div>
            </div>

	
</section>



<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>
<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.4.1/js/mdb.min.js'></script>
</html>