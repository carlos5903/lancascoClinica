<?php
include_once 'conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$_POST = json_decode(file_get_contents("php://input"), true);
$id = (isset($_POST['id'])) ? $_POST['id'] : '';
$dep = (isset($_POST['departamento'])) ? $_POST['departamento']: '';
$nom = (isset($_POST['nombre'])) ? $_POST['nombre']: '';
$pue = (isset($_POST['puesto'])) ? $_POST['puesto']: '';
$ext = (isset($_POST['EXT'])) ? $_POST['EXT']: '';
$emp = (isset($_POST['empresa'])) ? $_POST['empresa']: '';
$pa = (isset($_POST['pais'])) ? $_POST['pais']: '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';

//viejos


switch($opcion){
    case 1:
       // INSERT INTO `extensiones`(`Departamento`, `Nombre`, `Puesto`, `EXT`, `Empresa`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])
        $consulta = "INSERT INTO extensiones (departamento, nombre, puesto, extension, empresa, pais) VALUES('$dep', '$nom', '$pue','$ext','$emp','$pa')";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();

        break;
    case 2:
        $consulta = "UPDATE extensiones SET departamento='$dep', nombre='$nom', puesto='$pue', extension='$ext', empresa='$emp', pais='$pa' WHERE id='$id'";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                        
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3:
        $consulta = "DELETE FROM extensiones WHERE id='$id'";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                           
        break;         
    case 4:
        $consulta = "SELECT id, departamento, nombre, puesto, extension, empresa, pais FROM extensiones ";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
}
print json_encode($data, JSON_UNESCAPED_UNICODE);
$conexion = NULL;